@echo off
title System Maintenance
:menu
cls
echo ------------------------------
echo        System Maintenance
echo ------------------------------
echo 1. Run System File Checker (SFC)
echo 2. Run DISM (Check Health)
echo 3. Run DISM (Scan Health)
echo 4. Run DISM (Restore Health)
echo 0. Exit
echo ------------------------------

set /p choice=Enter choice (1-4): 

if %choice%==1 (
    sfc /scannow
) else if %choice%==2 (
    DISM /Online /Cleanup-Image /CheckHealth
) else if %choice%==3 (
    DISM /Online /Cleanup-Image /ScanHealth
)  else if %choice%==4 (
    DISM.exe /Online /Cleanup-image /Restorehealth
) else if %choice%==0 (
    exit
) else (
    echo Invalid choice. Please enter a number between 1 and 4.
)

pause
goto menu
