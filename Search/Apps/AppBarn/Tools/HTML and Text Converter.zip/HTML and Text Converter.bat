@echo off
title HTML and Text Converter
cls

:menu
cls
echo ==============================
echo   Convert HTML and Text Files
echo ==============================
echo 1. Convert .html to .txt
echo 2. Convert .txt to .html
echo 3. Exit
echo ==============================
set /p choice="Enter choice (1-3): "

if "%choice%"=="1" goto html2txt
if "%choice%"=="2" goto txt2html
if "%choice%"=="3" goto end
echo Invalid choice. Try again.
pause
goto menu

:html2txt
cls
echo Converting all .html files to .txt...
for %%i in (*.html) do (
    ren "%%i" "%%~ni.txt"
)
if not exist *.html echo No .html files found.
goto done

:txt2html
cls
echo Converting all .txt files to .html...
for %%i in (*.txt) do (
    ren "%%i" "%%~ni.html"
)
if not exist *.txt echo No .txt files found.
goto done


:done
echo.
echo Done.
pause
goto menu

:end
echo Exiting.