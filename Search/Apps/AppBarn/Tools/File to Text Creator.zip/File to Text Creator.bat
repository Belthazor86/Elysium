@echo off
setlocal enabledelayedexpansion

:: Iterate through all files in the current directory
for /f "delims=" %%F in ('dir /b /a-d') do (
    
    :: 1. Skip the script itself
    if /I "%%F" NEQ "%~nx0" (
        
        :: 2. Skip files that are already .txt
        if /I "%%~xF" NEQ ".txt" (
            
            echo Creating: "%%~nF.txt"
            
            :: 3. The quotes around "%%~nF.txt" are critical
            if not exist "%%~nF.txt" (
                copy /y NUL "%%~nF.txt" >nul
            )
        )
    )
)

echo.
echo Operation finished.
pause