@echo off
title HTML and PHP Converter
cls

:menu
cls
echo ==============================
echo   Convert HTML and PHP Files
echo ==============================
echo 1. Convert .html to .php
echo 2. Convert .php to .html
echo 3. Exit
echo ==============================
set /p choice="Enter choice (1-3): "

if "%choice%"=="1" goto html2php
if "%choice%"=="2" goto php2html
if "%choice%"=="3" goto end
echo Invalid choice. Try again.
pause
goto menu

:html2php
cls
echo Converting all .html files to .php...
for %%i in (*.html) do (
    ren "%%i" "%%~ni.php"
)
if not exist *.html echo No .html files found.
goto done


:php2html
cls
echo Converting all .php files to .html...
for %%i in (*.php) do (
    ren "%%i" "%%~ni.html"
)
if not exist *.php echo No .php files found.
goto done


:done
echo.
echo Done.
pause
goto menu

:end
echo Exiting.