@echo off
setlocal enabledelayedexpansion

REM Prompt user to select the game directory
echo Select the directory where your game is installed:
set "game_dir="
for /f "delims=" %%I in ('powershell -Command "Add-Type -AssemblyName System.Windows.Forms; $folder = New-Object System.Windows.Forms.FolderBrowserDialog; $folder.ShowDialog() | Out-Null; $folder.SelectedPath"') do set "game_dir=%%I"

REM Check if user canceled the dialog
if not defined game_dir (
    echo No directory selected. Exiting script.
    exit /b
)

REM Defragment the game directory
echo Defragmenting game files in "%game_dir%"...
defrag "%game_dir%" /D

echo Game defragmentation complete.
pause
