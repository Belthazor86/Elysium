@echo off
setlocal

REM Get the drive where this script is located
set "drive=%~d0"

echo Script location:
echo %~dp0
echo.

echo Optimizing drive %drive% ...
echo.

defrag %drive% /O /U /V

echo.
echo Optimization complete.
pause