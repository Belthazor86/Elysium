@echo off
setlocal enabledelayedexpansion

:: Loop through all files in the current directory
for %%F in (*) do (
    
    :: Skip the script itself so it doesn't move into a folder
    if not "%%F"=="%~nx0" (
        
        :: Check if it's a file and not already a directory
        if [%%~xF] NEQ [] (
            
            echo Processing: "%%~nF"
            
            :: Create the folder if it doesn't exist
            if not exist "%%~nF" (
                mkdir "%%~nF"
            )
        )
    )
)

echo.
echo Task Complete!
pause