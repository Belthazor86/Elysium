@echo off
title Text and Markdown Converter
cls

:menu
cls
echo ==============================
echo   Convert Text and Markdown Files
echo ==============================
echo 1. Convert .txt to .md
echo 2. Convert .md to .txt
echo 3. Exit
echo ==============================
set /p choice="Enter choice (1-3): "

if "%choice%"=="1" goto txt2md
if "%choice%"=="2" goto md2txt
if "%choice%"=="3" goto end
echo Invalid choice. Try again.
pause
goto menu

:txt2md
cls
echo Converting all .txt files to .md...
for %%i in (*.txt) do (
    ren "%%i" "%%~ni.md"
)
if not exist *.txt echo No .txt files found.
goto done

:md2txt
cls
echo Converting all .md files to .txt...
for %%i in (*.md) do (
    ren "%%i" "%%~ni.txt"
)
if not exist *.md echo No .md files found.
goto done


:done
echo.
echo Done.
pause
goto menu

:end
echo Exiting.