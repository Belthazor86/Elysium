@echo off
setlocal enabledelayedexpansion

echo -------------------------------------------------------
echo  Compression Started 
echo -------------------------------------------------------

:: Loop through every file and folder
for /f "delims=" %%I in ('dir /b /a-h') do (
    
    :: Skip the script itself and any zip files
    if /i not "%%~nxI"=="%~nx0" if /i not "%%~xI"==".zip" (
        
        echo Compressing: %%I...
        
        :: The \" quotes below are the fix for the spaces issue
        powershell -NoProfile -Command "Compress-Archive -Path \"%%I\" -DestinationPath \"%%~nI.zip\" -Force -ErrorAction SilentlyContinue"
    )
)

echo -------------------------------------------------------
echo  Finished!
echo -------------------------------------------------------
pause