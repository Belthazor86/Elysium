@echo off
title Check Disk Utility

:: Get the drive letter where this script is located
set DRIVE=%~d0

:menu
cls
echo ------------------------------
echo         Check Disk Utility
echo ------------------------------
echo Current Drive: %DRIVE%
echo ------------------------------
echo 1. Check Disk (Read-Only Scan)
echo 2. Check Disk and Fix Errors
echo 3. Check Disk, Fix Errors, and Recover Bad Sectors
echo 4. Schedule Check Disk on Next Restart
echo 0. Exit
echo ------------------------------

set /p choice=Enter choice (0-4): 

if %choice%==1 (
    chkdsk %DRIVE%
) else if %choice%==2 (
    chkdsk %DRIVE% /f
) else if %choice%==3 (
    chkdsk %DRIVE% /f /r
) else if %choice%==4 (
    chkdsk %DRIVE% /f /r /x
) else if %choice%==0 (
    exit
) else (
    echo Invalid choice. Please enter a number between 0 and 4.
)

pause
goto menu