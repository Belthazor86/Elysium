@echo off
title Software Link Manager
setlocal EnableDelayedExpansion

:MENU
cls
echo ========================
echo  Software Link Manager
echo ========================
echo 1. Create a link
echo 2. Access a link
echo 3. Delete a link
echo 0. Exit the program
set /p choice=Enter your choice (0-3): 

if "%choice%"=="1" (
    call :CreateLink
) else if "%choice%"=="2" (
    call :AccessLink
) else if "%choice%"=="3" (
    call :DeleteLink
) else if "%choice%"=="0" (
    call :ExitProgram
) else (
    echo Invalid choice. Please enter a number between 0 and 3.
    pause
    goto :MENU
)

:CreateLink
cls
set /p linkName=Enter the link name (0 to go back to the menu): 
if /i "%linkName%"=="0" goto :MENU

echo Opening file dialog to select the executable file...
set "exeFilter=Executable Files (*.exe);;All Files (*.*)"
set "dialogTitle=Select the executable file for %linkName%"
for /f "delims=" %%# in ('powershell -Command "& {Add-Type -AssemblyName System.Windows.Forms; $fd = New-Object System.Windows.Forms.OpenFileDialog; $fd.Filter = '%exeFilter%'; $fd.Title = '%dialogTitle%'; $fd.ShowDialog() | Out-Null; $fd.FileName}"') do set "exePath=%%#"

if not defined exePath (
    echo No file selected. Aborting link creation.
    pause
    goto :MENU
)

echo %linkName%=%exePath% >> links.txt
echo Software link created successfully!

set /p createAnotherLink=Do you want to create another link? (Y/N): 
if /i "%createAnotherLink%"=="Y" goto :CreateLink
goto :MENU

:AccessLink
cls
setlocal EnableDelayedExpansion
set count=1
echo List of available links:
for /f "tokens=1,* delims==" %%a in (links.txt) do (
    echo !count!. %%a
    set "link[!count!]=%%b"
    set /a count+=1
)

set /p linkNumber=Enter the number of the link to access (0 to go back to the menu): 
if !linkNumber! geq 0 if !linkNumber! leq !count! (
    if !linkNumber! equ 0 (
        goto :MENU
    ) else (
        start "" "!link[%linkNumber%]!"
        goto :AccessLinkPrompt
    )
) else (
    echo Invalid link number!
    pause
    goto :MENU
)

:AccessLinkPrompt
set /p accessAnotherLink=Do you want to access another link? (Y/N): 
if /i "%accessAnotherLink%"=="Y" goto :AccessLink
goto :MENU

:DeleteLink
cls
set /p linkName=Enter the link name to delete (0 to go back to the menu): 
if /i "%linkName%"=="0" goto :MENU

set "linkDeleted="
(for /f "tokens=1,* delims==" %%a in (links.txt) do (
    if /i "%%a" neq "%linkName%" echo %%a=%%b
    if /i "%%a" equ "%linkName%" set "linkDeleted=1"
)) > temp.txt

if not defined linkDeleted (
    echo Link not found!
    pause
    goto :MENU
)

move /y temp.txt links.txt
echo Link deleted successfully!

set /p deleteAnotherLink=Do you want to delete another link? (Y/N): 
if /i "%deleteAnotherLink%"=="Y" goto :DeleteLink
goto :MENU

:ExitProgram
echo Goodbye!
endlocal
exit 
exit /b
exit 123
goto :eof
