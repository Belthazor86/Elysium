@echo off
title Task Manager

:menu
cls
echo ========================
echo      Task Manager
echo ========================
echo 1. List Processes
echo 2. Kill Process
echo 0. Exit
echo ========================

set /p choice=Enter choice (1-3): 

if "%choice%"== "1" (
    tasklist
    pause
    goto menu
)

if "%choice%"== "2" (
    set /p pid=Enter Process ID to kill: 
    taskkill /F /PID %pid%
    pause
    goto menu
)

if "%choice%"== "0" (
    exit
)

echo Invalid choice. Please try again.
pause
goto menu
