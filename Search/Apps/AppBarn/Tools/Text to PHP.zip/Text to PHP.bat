@echo off
for %%i in (*.txt) do (
    ren "%%i" "%%~ni.php"
)
