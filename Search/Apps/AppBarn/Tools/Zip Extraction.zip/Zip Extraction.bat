@echo off
setlocal enabledelayedexpansion

:: Loop through every .zip file in the current directory
for %%F in (*.zip) do (
    echo Extracting: "%%F"
    
    :: Create a folder with the same name as the zip file
    mkdir "%%~nF" 2>nul
    
    :: Extract the contents into that folder
    tar -xf "%%F" -C "%%~nF"
)

echo.
echo All files have been extracted into individual folders.
pause