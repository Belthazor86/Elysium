@echo off
for %%i in (*.php) do (
    ren "%%i" "%%~ni.txt"
)
