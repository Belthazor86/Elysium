@echo off
title PHP and Text Converter
cls

:menu
cls
echo ==============================
echo   Convert PHP and Text Files
echo ==============================
echo 1. Convert .php to .txt
echo 2. Convert .txt to .php
echo 3. Exit
echo ==============================
set /p choice="Enter choice (1-3): "

if "%choice%"=="1" goto php2txt
if "%choice%"=="2" goto txt2php
if "%choice%"=="3" goto end
echo Invalid choice. Try again.
pause
goto menu

:php2txt
cls
echo Converting all .php files to .txt...
for %%i in (*.php) do (
    ren "%%i" "%%~ni.txt"
)
if not exist *.php echo No .php files found.
goto done

:txt2php
cls
echo Converting all .txt files to .php...
for %%i in (*.txt) do (
    ren "%%i" "%%~ni.php"
)
if not exist *.txt echo No .txt files found.
goto done


:done
echo.
echo Done.
pause
goto menu

:end
echo Exiting.