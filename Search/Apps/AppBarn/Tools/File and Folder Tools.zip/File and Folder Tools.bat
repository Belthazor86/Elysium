@echo off
setlocal enabledelayedexpansion

title File and Folder Tools
cls

:menu
cls
echo ==============================
echo   File and Folder Files
echo ==============================
echo 1. File to Folder Creator
echo 2. File to Folder Mover
echo 3. File and Folder Compression
echo 4. Exit
echo ==============================
set /p choice="Enter choice (1-3): "

if "%choice%"=="1" goto f2fcreate
if "%choice%"=="2" goto f2fmove
if "%choice%"=="3" goto f2fcompress
if "%choice%"=="4" goto end
echo Invalid choice. Try again.
pause
goto menu

:f2fcreate
cls
echo Converting Files to Folders...
:: Loop through all files in the current directory
for %%F in (*) do (
    
    :: Skip the script itself so it doesn't move into a folder
    if not "%%F"=="%~nx0" (
        
        :: Check if it's a file and not already a directory
        if [%%~xF] NEQ [] (
            
            echo Processing: "%%~nF"
            
            :: Create the folder if it doesn't exist
            if not exist "%%~nF" (
                mkdir "%%~nF"
            )
        )
    )
)
goto done

:f2fmove
cls
echo Moving files into folders...
:: Loop through all files in the current directory
for %%F in (*) do (
    
    :: Skip the script itself so it doesn't move into a folder
    if not "%%F"=="%~nx0" (
        
        :: Check if it's a file and not already a directory
        if [%%~xF] NEQ [] (
            
            echo Processing: "%%~nF"
            
            :: Create the folder if it doesn't exist
            if not exist "%%~nF" (
                mkdir "%%~nF"
            )
            
            :: Move the file into the folder
            move "%%F" "%%~nF\"
        )
    )
)
if not exist *.md echo No .md files found.
goto done


:f2fcompress
cls
echo Compressing files and/or folders...
:: Loop through every file and folder
for /f "delims=" %%I in ('dir /b /a-h') do (
    
    :: Skip the script itself and any zip files
    if /i not "%%~nxI"=="%~nx0" if /i not "%%~xI"==".zip" (
        
        echo Compressing: %%I...
        
        :: The \" quotes below are the fix for the spaces issue
        powershell -NoProfile -Command "Compress-Archive -Path \"%%I\" -DestinationPath \"%%~nI.zip\" -Force -ErrorAction SilentlyContinue"
    )
)
if not exist *.md echo No .md files found.
goto done








:done
echo.
echo Task Complete!
pause
goto menu

:end
echo Exiting.