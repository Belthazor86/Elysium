@echo off
title System Information

:menu
cls
echo =============================
echo        System Information
echo =============================
echo 1. Display System Information
echo 2. Exit
echo =============================

set /p choice=Enter your choice: 

if "%choice%"== "1" (
    call :displaySystemInfo
) else if "%choice%"== "2" (
    exit
) else (
    echo Invalid choice. Please try again.
    pause
    goto menu
)

:displaySystemInfo
cls
echo =============================
echo        System Information
echo =============================
systeminfo
pause
goto menu
