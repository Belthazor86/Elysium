@echo off
setlocal enabledelayedexpansion

:: Get the full path of the current folder to avoid "Drive not found" errors
set "workDir=%~dp0"
cd /d "%workDir%"

echo Scanning in: "%workDir%"
echo ----------------------------------

for %%f in (*.rar *.7z *.tar) do (
    echo Processing: "%%f"
    
    set "baseName=%%~nf"
    set "tmpDir=%workDir%tmp_!baseName!"

    :: Create temp folder using full path
    if not exist "!tmpDir!" mkdir "!tmpDir!"

    :: Extract using full paths
    tar -xf "%%f" -C "!tmpDir!"

    :: Compress using PowerShell with literal path strings
    powershell -command "Compress-Archive -LiteralPath '!tmpDir!' -DestinationPath '!baseName!.zip' -Force"

    :: Cleanup
    rd /s /q "!tmpDir!"
    
    echo Success: "!baseName!.zip"
)

echo ----------------------------------
pause