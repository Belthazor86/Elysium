@echo off
wmic memphysical get MaxCapacity, MemoryDevices
pause






REM wmic`: This stands for Windows Management Instrumentation Command-line. It allows you to interact with various system information and management features via the command prompt.

REM memphysical`: This specifies that we want information related to physical memory (RAM).

REM get MaxCapacity, MemoryDevices`: This part of the command requests specific properties to be displayed. It retrieves the maximum capacity of RAM (MaxCapacity) and the number of memory devices (MemoryDevices).


