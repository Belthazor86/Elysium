@echo off
setlocal EnableDelayedExpansion

:MENU
cls
echo Welcome to the YouTube Link Manager
echo ----------------------------------
echo 1. Create a link
echo 2. Access a link
echo 3. Delete a link
echo 0. Exit the program
set /p choice=Enter your choice (0-3): 

if "%choice%"=="1" (
    call :CreateLink
) else if "%choice%"=="2" (
    call :AccessLink
) else if "%choice%"=="3" (
    call :DeleteLink
) else if "%choice%"=="0" (
    call :ExitProgram
) else (
    echo Invalid choice. Please enter a number between 0 and 3.
    pause
    goto :MENU
)

:CreateLink
set /p linkName=Enter the link name (0 to go back to the menu): 
if /i "%linkName%"=="0" goto :MENU
set /p linkURL=Enter the link URL: 
echo %linkName%=%linkURL% >> links.txt
echo Link created successfully!

set /p createAnotherLink=Do you want to create another link? (Y/N): 
if /i "%createAnotherLink%"=="Y" goto :CreateLink
goto :MENU

:AccessLink
setlocal EnableDelayedExpansion
set count=1
echo List of available links:
for /f "tokens=1,* delims==" %%a in (links.txt) do (
    echo !count!. %%a
    set "link[!count!]=%%b"
    set /a count+=1
)

set /p linkNumber=Enter the number of the link to access (0 to go back to the menu): 
if !linkNumber! geq 0 if !linkNumber! leq !count! (
    if !linkNumber! equ 0 (
        goto :MENU
    ) else (
        start "" "!link[%linkNumber%]!"
        goto :AccessLinkPrompt
    )
) else (
    echo Invalid link number!
    pause
    goto :MENU
)

:AccessLinkPrompt
set /p accessAnotherLink=Do you want to access another link? (Y/N): 
if /i "%accessAnotherLink%"=="Y" goto :AccessLink
goto :MENU

:DeleteLink
set /p linkName=Enter the link name to delete (0 to go back to the menu): 
if /i "%linkName%"=="0" goto :MENU
findstr /i /v /c:"%linkName%" links.txt > temp.txt
move /y temp.txt links.txt
echo Link deleted successfully!

set /p deleteAnotherLink=Do you want to delete another link? (Y/N): 
if /i "%deleteAnotherLink%"=="Y" goto :DeleteLink
goto :MENU

:ExitProgram
echo Goodbye!
endlocal
exit 
exit /b
exit 123
goto :eof

