@echo off
title Networking Commands
:menu
cls
echo ============================
echo      Networking Commands
echo ============================
echo 1. IP Configuration
echo 2. Ping
echo 3. Traceroute
echo 4. Display Open Ports
echo 5. Show ARP Table
echo 6. DNS Lookup
echo 7. Interface Stats (Netstat)
echo 8. Network Interfaces (Netsh)
echo 9. NetBIOS over TCP/IP (Nbtstat)
echo 10. Network Diagnostics (Pathping)
echo 0. Exit
echo ============================
set /p choice=Enter the number of your choice: 

if "%choice%"=="1" goto ipconfig_command
if "%choice%"=="2" goto ping_command
if "%choice%"=="3" goto tracert_command
if "%choice%"=="4" goto netstat_command
if "%choice%"=="5" goto arp_command
if "%choice%"=="6" goto nslookup_command
if "%choice%"=="7" goto netstat_interface_command
if "%choice%"=="8" goto netsh_command
if "%choice%"=="9" goto nbtstat_command
if "%choice%"=="10" goto pathping_command
if "%choice%"=="0" goto end

:ipconfig_command
ipconfig /all
pause
goto menu

:ping_command
set /p ip_address=Enter the IP address to ping: 
ping %ip_address% -n 4
pause
goto menu

:tracert_command
set /p ip_address=Enter the IP address for traceroute: 
tracert %ip_address%
pause
goto menu

:netstat_command
netstat -an
pause
goto menu

:arp_command
arp -a
pause
goto menu

:nslookup_command
set /p domain_name=Enter the domain name for DNS lookup: 
nslookup %domain_name%
pause
goto menu

:netstat_interface_command
netstat -i
pause
goto menu

:netsh_command
netsh interface show interface
pause
goto menu

:nbtstat_command
set /p remote_host=Enter the remote host for Nbtstat: 
nbtstat -a %remote_host%
pause
goto menu

:pathping_command
set /p ip_address=Enter the IP address for pathping: 
pathping %ip_address%
pause
goto menu

:end
echo Exiting...
